<?php
session_start();
include 'config.php';

$error = '';
if (isset($_POST['login'])) {
    if (empty($_POST['username']) || empty($_POST['password'])) {
        $error = "Username or Password Tidak Valid!";
    } else {
        $user = $_POST['username'];
        $pass = $_POST['password'];

        // Membuat koneksi ke database
        $conn = mysqli_connect($host, $username, $password, $database);

        // Memeriksa koneksi
        if (!$conn) {
            die("Koneksi gagal: " . mysqli_connect_error());
        }

        // Melakukan pengamanan terhadap input
        $user = mysqli_real_escape_string($conn, $user);
        $pass = mysqli_real_escape_string($conn, $pass);

        // Melakukan query dengan prepared statement
        $query = "SELECT username, password FROM users WHERE username=? AND password=md5(?)";
        $stmt = mysqli_prepare($conn, $query);

        // Bind parameter
        mysqli_stmt_bind_param($stmt, "ss", $user, $pass);

        // Eksekusi statement
        mysqli_stmt_execute($stmt);

        // Simpan hasil
        mysqli_stmt_store_result($stmt);

        // Memeriksa jumlah baris yang ditemukan
        if (mysqli_stmt_num_rows($stmt) == 1) {
            $_SESSION['username'] = $user;
            header("location: dashboard/index.php");
            exit(); // Penting untuk menghentikan eksekusi script setelah redirect
        } else {
            $error = "Username atau Password Salah!";
        }

        // Menutup statement
        mysqli_stmt_close($stmt);

        // Menutup koneksi
        mysqli_close($conn);
    }
}
?>

<!-- Tambahan: menampilkan pesan kesalahan -->
<?php if (!empty($error)) : ?>
    <script language="JavaScript">
        alert('<?php echo $error; ?>');
        window.location='index.php';
    </script>
<?php endif; ?>
