# Implementasi AES pada FILE
Aplikasi PHP Enkripsi-Dekripsi File Menggunakan Algoritma Advanced Encryption Standard (AES-128)

# Cara Penggunaan
Untuk menggunakan Aplikasi ini buatlah 2 folder di dalam folder dashboard yakni
1. folder dengan nama "file_encrypt"
2. folder dengan nama "file_decrypt"

Note: program ini merupakan program kuliah kerja praktek (kkp/magang). Program ini direpository-kan untuk pembelajaran implementasi algoritma AES 128bit
